﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CraftingLogic
{
    public  static class Text
    {
        public static void Centered(string text) 
        { int width = Console.WindowWidth; 
            int left = (width - text.Length) / 2; 
            if (left < 0) left = 0;
            Console.SetCursorPosition(left, Console.CursorTop);
            Console.WriteLine(text); 
        
        }
        public static void WriteCentered(string text) 
        {
            int width = Console.WindowWidth; 
            int left = (width - text.Length) / 2; 
            if (left < 0) left = 0; Console.SetCursorPosition(left, Console.CursorTop);
            Console.Write(text); 
        }


    }
}