﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{
    public class Recipe
    {
        public string Name { get; set; }
        public string Description { get; set; }

        public float YieldAmount { get; set; }
        public string YieldType { get; set; }

        public float Value { get; set; }

        public List<Item> Ingredients { get; set; }

        public Recipe()
        {
            Ingredients = new List<Item>();
        }
    }

}