﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using static System.Console;


namespace CraftingLogic
{
    public class GameLogic
    {
        //creating a list of the recipes that are available in the xml file.
        public List<Recipe> LoadRecipes(string fileName)
        {
            List<Recipe> Recipes = new List<Recipe>();
            XmlDocument doc = new XmlDocument();
            doc.Load(@"../../data/recipes.xml"); 


            XmlNode root = doc.DocumentElement;
            XmlNodeList recipeList = root.SelectNodes("../../recipes/recipe");
            XmlNodeList ingredientsList;

            foreach (XmlElement recipe in recipeList)
            {
                Recipe recipeToAdd = new Recipe();
                recipeToAdd.Name = recipe.GetAttribute("title");
                recipeToAdd.Description = recipe.GetAttribute("description");
                string yieldAmount = recipe.GetAttribute("yieldAmount");
                if (float.TryParse(yieldAmount, out float amount))
                { recipeToAdd.YieldAmount = amount; }
                recipeToAdd.YieldType = recipe.GetAttribute("yieldType");
                string recipevalue = recipe.GetAttribute("value");
                if (float.TryParse(recipevalue, out float value))
                { recipeToAdd.Value = value; }

                ingredientsList = recipe.ChildNodes; //for ingredients
                foreach (XmlElement i in ingredientsList)
                {
                    string ingredientName = i.GetAttribute("itemName");
                    string ingredientAmountString = i.GetAttribute("amount");
                    float ingredientAmount = 0;
                    if (float.TryParse(ingredientAmountString, out float e))
                    { ingredientAmount = e; }
                    string ingredientAmountType = i.GetAttribute("amountType");
                    string tempIngredientValue = i.GetAttribute("value");
                    float ingredientValue = 0;
                    if (float.TryParse(tempIngredientValue, out float ingValue))
                    { ingredientValue = ingValue; }
                    recipeToAdd.Ingredients.Add(new Item(ingredientName, ingredientAmount, ingredientAmountType, ingredientValue));
                }
                Recipes.Add(recipeToAdd);
            }
            return Recipes;
        }

        public void StartGame()
        {
            Text.Centered("Welcome to the Crafting Game!");//welcome message
            Text.Centered("Press Enter to advance after each step...");
            ReadLine();

        }
        
        public void Setname(Person p)
        {
            p.SetName("");//Setting the players name, this will prompt the user to enter a name
            Text.Centered($"Player Name : {p.Name}");
            Clear();//clears the console to make it look nicer
            Text.Centered($"Welcome to the Crafting Game, {p.Name}!");//welcome message with the players name
            WriteLine();
            p.ShowMoney();

            p.ShowInventory();//showing inventory
            ReadLine();//waiting for user input before closing  
        }

      

    }
}