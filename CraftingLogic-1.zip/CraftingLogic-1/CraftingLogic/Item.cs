﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{
    //This class descibes items in the world.
    //Each item has a name an amount in the stack and a value for the item

    /*Would be useful to add function to show value per unit and value of stack
     */
    public class Item
    {
        public string Name;
        public float Qty;
        public string Amt;
        public float Value;

        public Item(string name, float qty, string amt, float value = 0)
        {
            Name = name;
            Qty = qty;
            Amt = amt;
            Value = value;
        }
    }

}