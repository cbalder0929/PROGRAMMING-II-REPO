﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using static System.Console;

namespace CraftingLogic
{
    //This class is the doer of stuff in this world
    public class Person
    {
        public string Name { get; set; }
        public List<Item> Inventory { get; }

        public int money { get; set; }

        public Person()
        {
            //constructor initializes name and empty inventory
            Name = "";
            money = 100; //starting money
            Inventory = new List<Item>();
            AddItem(new Item("Wood", 5,"5",2));//Adding some items to the inventory for testing
            AddItem(new Item("Stone", 3,"4",3));
            AddItem(new Item("Iron", 2,"3",4));
        }
        public void SetName(string name)
        {
            Text.Centered("First things first, give your character a name.");

            Text.WriteCentered("Enter player name:");
            //saving the position of the cursor
            int cursorLeft = CursorLeft; 
            int cursorTop = CursorTop;
            WriteLine();

            Text.Centered("Press Enter to Save name and Proceed");
            //allowws the directions to appear and then go back to the position to enter the name
            SetCursorPosition(cursorLeft, cursorTop);
            string inputName = ReadLine();

            Name = inputName;
            WriteLine();
            Text.Centered($"Nice to meet you {Name}");    
            ReadKey();

        }
        
        public void AddItem(Item item)
        {
            //adds item to inventory
            Inventory.Add(item);
        }
        public bool RemoveItem(Item item)
        {
            //removes item from inventory, returns true if successful
            return Inventory.Remove(item);
        }
        public void ShowInventory()
        {
            Text.Centered("Press enter to search for an item in the inventory...");
            //displays all items in inventory
            if (Inventory.Count == 0)
            {
                Text.Centered("Inventory is empty.");
            }
            else
            {
                Text.Centered("Inventory:");
                foreach (var item in Inventory)
                {
                    Text.Centered($"- {item.Name}");
                }

            }

            Text.Centered("\nPress enter to remove an item from the inventory and show the inventory again...");
            ReadLine();


        }
        public void ShowMoney()
        {
            Text.Centered($"Current Money: {money} coins");
        }

        public bool SearchCollectionByName(List<Item> list, string itemName)
        {
            return list.Any(i =>
                i.Name.Equals(itemName, StringComparison.OrdinalIgnoreCase));
        }

        public void Search()
        {
            Write("Enter item name to search: ");
            string name = ReadLine();

            bool found = SearchCollectionByName(Inventory, name);

            if (found)
                Text.Centered($"{name} is in your inventory.");
            else
                Text.Centered($"{name} is NOT in your inventory.");


        }
    }
}