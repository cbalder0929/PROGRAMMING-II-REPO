﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
// The code in this program was genrated witht the assitance of Janell Baxter and Copilot AI

namespace CraftingLogic
{
    public class Program
    {
        static void Main(string[] args)
        {

            Title = "Crafting Game 2026";//Setting the console title
            Person p = new Person();//instantiating the player
            GameLogic g = new GameLogic(); //instantiating the game logic and passing the player to it

            

            g.StartGame();//Starting the game logic

            g.Setname(p);//Setting the players name and showing inventory and money

            p.RemoveItem(p.Inventory[0]);//removing an item from the inventory for testing
            p.ShowInventory();//showing inventory after removing an item
            
            ReadLine();//waiting for user input before closing
            p.Search();
            ReadLine();


        }
    }
}
