﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;

namespace CraftingLogic
{
    //This class is the doer of stuff in this world
    public class Person
    {
        public string Name { get; set; }
        public List<Item> Inventory { get; set; }

        public Person(string name = "Player")
        {
            //constructor initializes name and empty inventory
            Name = name;
            Inventory = new List<Item>();
        }
        public void AddItem(Item item)
        {
            //adds item to inventory
            Inventory.Add(item);
        }
        public bool RemoveItem(Item item)
        {
            //removes item from inventory, returns true if successful
            return Inventory.Remove(item);
        }
        public void ShowInventory()
        {
            //displays all items in inventory
            if (Inventory.Count == 0)
            {
                WriteLine("Inventory is empty.");
            }
            else
            {
                WriteLine("Inventory:");
                foreach (var item in Inventory)
                {
                    WriteLine($"- {item.Name}");
                }

            }
        }
    }
}