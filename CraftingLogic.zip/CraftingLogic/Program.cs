﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace CraftingLogic
{
    public class Program
    {
        static void Main(string[] args)
        {
            Library l = new Library();//This is the classes being instantiated to be used in the main program
            Person p = new Person();
            GameLogic g = new GameLogic();

            g.StartGame();//Starting the game logic
            ReadLine();//waiting for user input
            g.StartMenu();//Starting the main menu shows name an inventory
            ReadLine();//waiting for user input before closing  

        }
    }
}
