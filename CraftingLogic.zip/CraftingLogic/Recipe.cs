﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{

    public class RecipeMenu
    {
        //shows list of recipes available to craft
        public List<Recipe> Recipes { get; set; }
        public RecipeMenu()
        {
            Recipes = new List<Recipe>();
        }
        public void AddRecipe(Recipe recipe)
        {
            Recipes.Add(recipe);
        }
        public void ShowRecipes()
        {
            foreach (var recipe in Recipes)
            {
                WriteLine($"Recipe: {recipe.Name}");
            }
        }
    }
    public class Recipe
    {
        public string Name;// tells you what will be crafted
        public int OutputQuantity;//tells you how many will be crafted
        public int Value;// how much the crafted item is worth
        public Dictionary<Item, int> Ingredients { get;  set; }// list of the ingredients and their quantities needed to craft the item
        public Recipe(string name, int outputQuantity, int value)
        {
            //constructor for recipes
            Name = name;
            OutputQuantity = outputQuantity;
            Value = value;
            Ingredients = new Dictionary<Item, int>();
        }
        public void AddIngredient(Item item, int quantity)
        {
            Ingredients[item] = quantity;
        }


    }
}