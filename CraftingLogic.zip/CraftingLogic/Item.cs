﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{
    //This class descibes items in the world.
    //Each item has a name an amount in the stack and a value for the item

    /*Would be useful to add function to show value per unit and value of stack
     */
    public class Item
    {
        public string Name;
        public int Amount;
        public int Value;

        public Item(string name, int amount = 1, int value = 0)
        {
            Name = name;
            Amount = amount;
            Value = value;
        }

    }
}