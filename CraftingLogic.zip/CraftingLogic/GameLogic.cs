﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{
    public class GameLogic
    {
        Library l = new Library();//creating instance of person and library to use them
        Person p = new Person();
        public void StartGame()
        {
            
            l.Print("Enter your Name :");
            string inputName = Console.ReadLine();//setting the persons name
            p.Name = inputName;
            l.Print($"Nice to meet you {p.Name}");//dispalying new set name
            WriteLine("Press Enter to Save name and Proceed");

        }
        public void StartMenu()
        {
            Clear();
            WriteLine($"Player Name : {p.Name}");

            p.ShowInventory();//showing inventory

        }

    }
}