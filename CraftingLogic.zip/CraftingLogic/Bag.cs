﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{
    //This class is a container for items
    public class Bag
    {
        private int capacity;   //Max thinggs the bag can hold
        private List<Item> items;   //list of The items in the bag
    }

    // this class is not very nesscasary, will leave for now
}