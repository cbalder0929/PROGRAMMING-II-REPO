﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static System.Console;


namespace CraftingLogic
{
    public class Library
    {

        public void Print(string message) 
        {
            Console.WriteLine(message);
        
        }
    }
}